import streamlit as st
import os
from langchain_community.llms import Ollama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.runnables import RunnablePassthrough

# 1. Page Config
st.set_page_config(page_title="AI Insight Bot", layout="wide")

# Sidebar: Is baar Reset button ko mazeed powerful banaya ha
with st.sidebar:
    st.title("⚙️ Control Panel")
    if st.button("🔄 FORCE RELOAD DATA"):
        # Yeh sab kuch clear kar dega taake naya text load ho sake
        for key in st.session_state.keys():
            del st.session_state[key]
        st.rerun()
    st.info("Agar 'Not Found' aaye to upar wala button dabayein.")

st.title("🤖 Smart RAG Assistant")

if "messages" not in st.session_state:
    st.session_state.messages = []

file_path = "data/sample_docs.txt"

# --- CORE LOGIC ---
if not os.path.exists(file_path):
    st.error("⚠️ 'data/sample_docs.txt' nahi mili!")
else:
    try:
        # Embeddings
        embeddings = OllamaEmbeddings(model="llama2") 

        # 2. Database Loading (Memory check ke saath)
        if "vectorstore" not in st.session_state:
            with st.spinner("Processing your text file..."):
                loader = TextLoader(file_path, encoding="utf-8")
                documents = loader.load()
                
                # Small text ke liye splitter ko bilkul simple rakha ha
                text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
                docs = text_splitter.split_documents(documents)
                
                st.session_state.vectorstore = FAISS.from_documents(docs, embeddings)
        
        vectorstore = st.session_state.vectorstore
        # k=1 taake chote text mein koi confusion na ho
        retriever = vectorstore.as_retriever(search_kwargs={"k": 1})

        # 3. LLM Setup
        llm = Ollama(model="llama2", temperature=0.0)

        # 4. Strict Prompt
        template = """Answer ONLY using the context provided below. 
        If it's not there, say you can't find it.

        Context: {context}
        Question: {question}
        Answer:"""
        
        prompt = ChatPromptTemplate.from_template(template)

        # 5. Chain with ERROR FIX
        chain = (
            {"context": retriever, "question": RunnablePassthrough()}
            | prompt | llm | StrOutputParser()
        )

        # UI: Chat display
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

        # 6. User Input
        if user_query := st.chat_input("Ask from your document..."):
            st.session_state.messages.append({"role": "user", "content": user_query})
            with st.chat_message("user"):
                st.markdown(user_query)

            with st.chat_message("assistant"):
                with st.spinner("Searching..."):
                    # LangChain New Version Fix: get_relevant_documents ki jagah invoke
                    check_docs = retriever.invoke(user_query)
                    
                    if len(check_docs) == 0:
                        response = "I couldn't find any matching text in the file."
                    else:
                        response = chain.invoke(user_query)
                    
                    st.markdown(response)
            
            st.session_state.messages.append({"role": "assistant", "content": response})

    except Exception as e:
        st.error(f"Error: {e}")